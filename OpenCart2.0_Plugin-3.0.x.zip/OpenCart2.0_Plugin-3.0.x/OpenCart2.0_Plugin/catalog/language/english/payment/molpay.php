<?php
/**
 * MOLPay OpenCart Plugin
 * 
 * @package Payment Gateway
 * @author MOLPay Technical Team <technical@molpay.com>
 * @version 2.0
 */
 
// Text
$_['text_title'] = 'MOLPay Malaysia Online Payment Gateway (Visa, MasterCard, Maybank2u, MEPS, FPX, etc )';

<?php
/**
 * E2Pay Global Utama OpenCart Plugin
 * 
 * @package Payment Gateway
 * @author E2Pay Global Utama Technical Team <technical-sa@razer.com>
 * @version 3.0.8
 */
 
// Text
$_['text_title'] = 'E2Pay Global Utama';

// Channel
$_['channel_list']					= 	array(
											'e2Pay_DANA' 				=> 'Dana',
											'e2Pay_LINKAJA_APPLINK' 	=> 'LinkAja Applink',
											'e2Pay_SHOPEEPAY_JUMPAPP'	=> 'Shopeepay Jumpapp',
											'e2Pay_OVO'				    => 'OVO',
											'e2Pay_CIMB_OctoPay' 		=> 'CIMB OctoPay',
											'e2Pay_LINKAJA_QRIS' 		=> 'LinkAja Qris',
											'e2Pay_LINKAJA_WCO' 		=> 'LinkAja WCO',
											'e2Pay_CIMB_QRIS' 			=> 'CIMB Qris',
											'e2Pay_SHOPEEPAY_QRIS' 		=> 'ShopeePay Qris',
											'e2Pay_MBayar_QR' 			=> 'Mbayar QR',
											'e2Pay_MBayar_Auth' 		=> 'Mbayar Auth',
											'e2Pay_Alfamart' 			=> 'Alfamart',
											'e2Pay_GOPAY' 				=> 'GOPAY',
											'e2Pay_PERMATA_VA' 			=> 'Permata Virtual Account',
											'e2Pay_BNI_VA' 				=> 'BNI Virtual Account',
											'e2Pay_CIMB_VA' 			=> 'CIMB Virtual Account',
											'e2Pay_BCA_VA' 				=> 'BCA Virtual Account',
											'e2Pay_BRI_VA' 				=> 'BRI Virtual Account',
											'e2Pay_MANDIRI_VA' 			=> 'Mandiri Virtual Account',
											'e2Pay_CIMBOctoClicks_IB' 	=> 'CIMB Octo Clicks Internet Banking',
											'e2Pay_Kredivo_FN' 			=> 'Kredivo',
											'e2Pay_Indodana_FN' 		=> 'Indodana',
											'e2Pay_Indomaret' 			=> 'Indomaret',
											'e2Pay_DBankPro_IB' 		=> 'DBank Pro IB',
											'creditAO' 					=> 'CIMB NIAGA CC',
										);
